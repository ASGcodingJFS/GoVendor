import React, { useState }  from 'react'
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import {Link as MuiLink, Paper, InputAdornment, IconButton} from '@mui/material';
import { useNavigate} from 'react-router-dom';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import {Snackbar, SnackbarContent} from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useDispatch } from 'react-redux';
import { login } from '../Redux/AuthSlice';
import AdminHeader from '../../Header';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import { Visibility, VisibilityOff } from '@mui/icons-material';


function Copyright(props) {
    return (
      <Typography variant="body2" color="text.secondary" align="center" {...props}>
        {'Copyright © '}
        <MuiLink color="inherit" href="https://mui.com/">
          Your Website
        </MuiLink>{' '}
        {new Date().getFullYear()}
        {'.'}
      </Typography>
    );
  }

  
  const defaultTheme = createTheme();


  const adminCredentials = {

    email : 'adminasg@gmail.com',
    password : 'adminpass123'
  }

const Login = () => {
    // const handleSubmit = (event) => {
    //     event.preventDefault();
    //     const data = new FormData(event.currentTarget);
    //     console.log({
    //       email: data.get('email'),
    //       password: data.get('password'),
    //     });
    //   };

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [successOpen , setSuccessOpen] = useState(false);
    const [errorOpen , setErrorOpen] = useState(false);
    const [showPassword, setShowPassword] = React.useState(false);

    const [formErrors, setFormErrors] = useState({
   
      email: false,
      password: false,
    
  });

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const handleLogin = (event) => {
        event.preventDefault();

        //Create a FormData object from the current target, which is the form element 
        const data = new FormData(event.currentTarget); 
        const storedEmail = data.get('email');
        const storedPassword = data.get('password');

        let formIsValid = true;

        const newFormErrors = {

        
          email : !storedEmail.trim(),
          password : !storedPassword.trim(),
          

        }

       

        setFormErrors(newFormErrors);

        // Check if any form field is empty
        if (Object.values(newFormErrors).some(error => error)) {
            formIsValid = false;
        }

        
      


        if(formIsValid){
        if(storedEmail === adminCredentials.email && storedPassword === adminCredentials.password)
       {  
         
          dispatch(login ({email : storedEmail , isAdmin : true}));
          setSuccessOpen(true);
          setTimeout (() => {
              navigate('/admindashboard');
       }, 1000 )
      }
      else {
        // Check if the entered credentials match any vendor credentials in localStorage
        const vendorsData = Object.values(localStorage);
        const matchedVendor = vendorsData.find((vendorData) => {
          const vendor = JSON.parse(vendorData);
          return vendor.email === storedEmail && vendor.password === storedPassword;
        });

        if(!matchedVendor) {


        }
        if (matchedVendor) {
          // Dispatch the login action for the vendor
          dispatch(login({ email: storedEmail, isAdmin : false}));
          // Navigate to the VendorData component
          setTimeout(() => {
            navigate(`/vendordata/vendors_${storedEmail}`) 
        }, 1000)
        }
      else   
      {
        setErrorOpen(true);
        console.log('Invalid credentails');
        //alert('Login failed! Either username or password is wrong');
      }
    }
  }
}

const handleSnackbarClose = (event, reason) => {

  if(reason === 'clickaway'){
    return;
}

  setSuccessOpen(false);
  setErrorOpen(false);

};

    
      return (
        <>
        <AdminHeader/>
        <ThemeProvider theme={defaultTheme}>
          <Container component="main" maxWidth="xs">
            <CssBaseline />
            <Paper elevation={5} style={{padding : '20px'}}>
            <Box
              sx={{
                marginTop: 8,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              <Avatar sx={{ bgcolor: '#0955ed' }}>
                <LockOpenIcon/>
              </Avatar>
              <Typography component="h1" variant="h5">
                Sign in
              </Typography>
              <Box component="form" noValidate onSubmit={handleLogin} sx={{ mt: 3 }}>
                <Grid container spacing={2}>
  
              
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      id="email"
                      label="Email Address"
                      name="email"
                      error={formErrors.email}
                      helperText={formErrors.email ? "Email is required" : ""}
                      autoComplete="email"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="password"
                      label="Password"
                      type={showPassword ? 'text' : 'password'}
                      id="password"
                      error={formErrors.password}
                      helperText={formErrors.password ? "Password is required" : ""}
                      autoComplete="new-password"

                      InputProps={{
                        endAdornment : (
                          <InputAdornment position="end">
                          <IconButton
                            aria-label="toggle password visibility"
                            onClick={handleClickShowPassword}
                           // onMouseDown={handleMouseDownPassword}
                            edge="end"
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                         </IconButton>
                       </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>
                  
                </Grid>
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  sx={{ mt: 3, mb: 2 }}
                 // onClick={handleLogin}
                >
                  Login
                </Button>
             
              </Box>
            </Box>
            </Paper>
            <Copyright sx={{ mt: 5 }} />
          </Container>

          <Snackbar
              open = {successOpen}
              autoHideDuration={3000}
              onClose={handleSnackbarClose}
              >
                  <SnackbarContent message = "Login Sucessful" style={{backgroundColor:  '#4CAF50'}}></SnackbarContent>
              </Snackbar>

              <Snackbar
              open = {errorOpen}
              autoHideDuration={3000}
              onClose={handleSnackbarClose}
              >
                  <SnackbarContent message = "Login failed! Either email or password is wrong" 
                  style={{backgroundColor:  '#F44336'}}></SnackbarContent>
              </Snackbar>
              
        </ThemeProvider>
        </>
      );
}

export default Login;