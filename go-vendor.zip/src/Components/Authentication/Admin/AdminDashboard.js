import React, { useEffect, useRef, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { selectVendors, fetchVendors, updatedVendorStatus } from '../Redux/VendorSlice';
import { Accordion, Button ,Box, Grid, Paper, Table, TableBody, TableCell, TableContainer, 
  TableHead, TableRow, Typography, Badge, 
Dialog, DialogContent,DialogTitle} from '@mui/material';
import AdminHeader, { DrawerHeader, Main } from '../../Header';
import { AdminPanelSettings, Group, Mail, PendingActions, ToggleOn } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';


const AdminDashboard = () => {
  const dispatch = useDispatch();
  const vendors = useSelector(selectVendors);
  const dataFetch = useRef(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedVendor, setSelectedVendor] = useState(null);
  const [requests, setRequests] = useState({});
  const navigate = useNavigate();
  
 // const classes = useStyles();


  useEffect(() => {

    console.log("hello outside if");
    if (!dataFetch.current) {
      dispatch(fetchVendors());
      dataFetch.current = true;
      console.log("hello");
    }
  }, [dispatch]);
  
  
  useEffect(() => {

    const tempcategories = JSON.parse(localStorage.getItem('tempcategories')) || [];
    const requestCount = tempcategories.reduce((count, category)=> {

      count[category.vendorKey] = (count[category.vendorKey] || 0) + 1;
      return count;
    },{});
    setRequests(requestCount);
  },[vendors])



  const handleToggleStatus = (vendorKey) => {
    // Find the vendor index in the Redux store
    const vendorIndex = vendors.findIndex(vendor => vendor.vendorKey === vendorKey);
  
    if (vendorIndex !== -1) {
      // Toggle the status
      const updatedStatus = vendors[vendorIndex].status === 'inactive' ? 'active' : 'inactive';
      
      // Update the Redux store
      const updatedVendors = [...vendors];
      updatedVendors[vendorIndex] = { ...vendors[vendorIndex], status: updatedStatus };
      dispatch(updatedVendorStatus(updatedVendors[vendorIndex]));
      
      // Update localStorage with the updated status
      localStorage.setItem(vendorKey, JSON.stringify(updatedVendors[vendorIndex]));
    }

    
};
//const vendorStatusC = handleToggleStatus(vendors.vendorKey);

  const handleClickVendor = (vendorKey) => {

      navigate(`/viewservicesadmin/${vendorKey}`)
  };

  const handleBadgeClick = (vendorKey) => {
    setSelectedVendor(vendorKey);
    setOpenDialog(true);
  };

     return (
               <>
                    <AdminHeader/>
                    {/* <div style={{marginLeft: "450px", marginBottom : "10px "}}> */}
                  
                <Accordion style={{padding : "20px"}}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
               <Typography variant='h5' >Admin Dashboard
            
               
               </Typography>
               <AdminPanelSettings fontSize='medium'/>
               </div>
               
               </Accordion>
               {/* </div> */}
                      <TableContainer component={Paper}>
                        <Table sx={{minWidth : 650}} aria-label="simple table">
                          <TableHead>
                            <TableRow>
                              <TableCell align="left">
                                <Box display="flex" alignItems="center" >
                                  <b>Vendor Name</b>
                                  <Group/>
                                   </Box></TableCell>

                              <TableCell align="left">
                                <Box display="flex" alignItems="center">
                                <b>Email</b>
                                <Mail/>
                                </Box>
                                </TableCell>
                              <TableCell align="left">
                                <Box display="flex" alignItems="center">
                                <b>Status</b>
                                <ToggleOn fontSize='large'/>
                                </Box>
                                </TableCell>
                              <TableCell align="left">
                                <Box display="flex" alignItems="center">
                                <b>Action</b>
                                <PendingActions/>
                                </Box>
                                </TableCell>
                                <TableCell align="left">
                                  <Box display="flex" alignItems="center">
                                    <b>Services</b>
                                  </Box>
                                </TableCell>
                              
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {vendors.map((vendor, index) => (
                              <TableRow key={index}>
                                <TableCell scope="row">{vendor.firstName} {vendor.lastName}</TableCell>
                                <TableCell scope="row">{vendor.email}</TableCell>
                                <TableCell scope="row" align='center'>
                                  <Box display="flex" alignItems="center">
                                  <Badge
                                    overlap="circular"
                                    anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                                    badgeContent={
                                      <div style={{ backgroundColor : vendor.status==='active'? 'green' : 'red', 
                                      width: 10, height: 10, borderRadius: "50%", marginRight : "15px"
                                      }} />}></Badge>
                                      {vendor.status} 
                                 
     
                                  </Box></TableCell>
                                <TableCell scope="row"> {/* Button to toggle status */}
                                  <Button onClick={() => handleToggleStatus(vendor.vendorKey)}
                                   variant='contained'
                                  style={{backgroundColor : vendor.status==='active'? 'red' : 'green'}} >
                                     {vendor.status === 'active' ? 'Deactivate' : 'Activate'} 
                                  </Button>
                                </TableCell>
                                {/* <TableCell scope="row" align='center'>
                  <Box display="flex" alignItems="center">
                    <Badge
                      overlap="circular"
                      anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                      badgeContent={requests[vendor.vendorKey] || 0}
                      onClick={() => handleBadgeClick(vendor.vendorKey)}
                    />
                  
                  </Box>
                </TableCell> */}
                                <TableCell scope="row">
                                  <Button variant="contained" onClick={()=>handleClickVendor(vendor.vendorKey)}>
                                    View Services
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                    </TableContainer>
                    <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle>Requests</DialogTitle>
        <DialogContent>
          {selectedVendor && (
            <ul>
              {/* Display category names for the selected vendor */}
            </ul>
          )}
        </DialogContent>
      </Dialog>
                 
                </>
            );
};

export default AdminDashboard;
