import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { selectServices } from '../Redux/ServiceSlice'
import AdminHeader from '../../Header'
import { Typography, Grid, Paper, Divider, Button } from '@mui/material'
import { fetchServicesForVendor } from '../Redux/ServiceSlice'
import { useLocation, useParams } from 'react-router-dom'

const ViewServicesAdmin = () => {

   // const services = useSelector(selectServices);
   // const dispatch = useDispatch();
    const {vendorKey} = useParams();
    const [services, setServices] = useState([]);
    const [requestedCategories, setRequestedCategories] = useState([]);
    
    // useEffect(() =>{
    //     dispatch(fetchServicesForVendor(vendorKey));
    //     console.log("hello");
    // },[dispatch, vendorKey])

    useEffect(() => {
  
        console.log("hello from services view");
        const localStorageData = JSON.parse(localStorage.getItem('services')) || [];
        console.log("localstoragedata", localStorageData);
        //const vendorServices = localStorageData.filter(service => service.vendorKey === vendorKey);
        const vendorServices = localStorageData.filter(service => {
          console.log("service.vendorKey:", service.vendorKey.vendorKey);
          console.log("vendorKeyUse:", vendorKey);
          return service.vendorKey.vendorKey === vendorKey;
        });
        
        console.log("vendorServices", vendorServices);
       // console.log("vendorKeyUse:", vendorKey);
        setServices(vendorServices);
      }, [vendorKey]);

      useEffect(() => {

          const storedTempCategories = JSON.parse(localStorage.getItem('tempcategories')) || [];
          const vendorRequestCategories = storedTempCategories.filter(entry => entry.key === vendorKey);
          setRequestedCategories(vendorRequestCategories);

      },[vendorKey]);

      const handleApprove = (categoryName) => {
        const updatedCategories = requestedCategories.filter(category => category.name !== categoryName);
        setRequestedCategories(updatedCategories);
        const listedCategories = JSON.parse(localStorage.getItem('listedcategory')) || [];
        if (!listedCategories.includes(categoryName)) {
          localStorage.setItem('listedcategory', JSON.stringify([...listedCategories, categoryName]));
        }

        const tempCategories = JSON.parse(localStorage.getItem('tempcategories')) || [];
        const updatedTempCategories = tempCategories.filter(category => category.name !== categoryName);
        localStorage.setItem('tempcategories', JSON.stringify(updatedTempCategories));

        setServices(prevServices => prevServices.filter(service => service.name !== categoryName));
      };

      const handleReject = (name) => {
        // Remove the category from tempcategories in localStorage
        const tempCategories = JSON.parse(localStorage.getItem('tempcategories')) || [];
        const updatedTempCategories = tempCategories.filter(category => category.name !== name);
        localStorage.setItem('tempcategories', JSON.stringify(updatedTempCategories));
    
        // Remove the category from the UI by updating state
        setServices(prevServices => prevServices.filter(service => service.name !== name));
      };

  return (
    <>
    <AdminHeader />
    <Typography variant="h4" gutterBottom style={{ padding: '20px' }}>
      View Services
    </Typography>
    <Grid container spacing={2}>
      {services.map((service, index) => (
        <Grid key={index} item xs={12} sm={6}>
          <Paper elevation={3} style={{ padding: '20px', marginBottom: '10px' }}>
            <Typography variant="h6">
              <b>Service Name:</b> {service.name}
            </Typography>
            <Divider />
            <Typography variant="body1">
              <b>Cost:</b> {service.cost}
            </Typography>
            <Typography variant="body1">
              <b>Description:</b> {service.description}
            </Typography>
            <Typography variant="body1">
              <b>Category:</b> {service.category}
            </Typography>

            {requestedCategories.map((category, index)=> (
                <>
                <Typography variant="h6">
                <b>Requested Category:</b> {category.name}
                </Typography>
                   <Button variant="contained" onClick={() => handleApprove(category.name)}>Approve</Button>
                   <Button variant="contained" onClick={() => handleReject(category.name)}>Reject</Button>
              </>
           ))}
          </Paper>
 
        </Grid>
      ))}
    </Grid>
  </>
  )
}

export default ViewServicesAdmin