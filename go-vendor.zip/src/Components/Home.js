import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { Typography, Button, Dialog, DialogContent, DialogActions, Grid } from '@mui/material'
import AdminHeader, { DrawerHeader, Main } from './Header';
import PersistentDrawerLeft from './DrawerHeader';


/* This is the home page - Right now it only consists of the header and buttons .
 The header part should be properly studied and further implmentations to be done */
const Home = () => {

  const [dialogOpen, setDialogOpen] = useState(false);
  const navigate = useNavigate();

  //For Login Button
  const handleClicked = () => {
    navigate('/login');
  }


  //For Sign up button
  const handleRegister = () => {
    navigate('/register');
  }

  //For Dialog Box
  const handleDialogOpen = () => {
    setDialogOpen(true);
  }

  const handleDialogClose = () => {
    setDialogOpen(false);
  }



  return (
    <div>
        {/* <Header/> */}
      
        {/* <PersistentDrawerLeft/> */}
        <Grid container direction="column" alignItems="center">

        <AdminHeader/>
        
         <Main>
          <DrawerHeader/>
        <Typography variant="h4" sx={{ mt: 2 , mb:2}}>Who are you?</Typography>

        <Grid container justifyContent="center" spacing={2}>
        <Grid item xs={12} md={6}>
        <Button variant="contained" fullWidth onClick={handleClicked}>Admin
        </Button>
        </Grid>
        <Grid item xs={12} md={6}>
        <Button variant="contained" fullWidth onClick={handleDialogOpen}>Vendor
        </Button>
        </Grid>
        </Grid>
        <Dialog
          open = {dialogOpen}
          onClose={handleDialogClose}
          >
            <DialogContent>What do you want to do?</DialogContent>
              <DialogActions>
                <Button onClick={handleClicked}>Login</Button>
                <Button onClick={handleRegister}>Create an account</Button>
            </DialogActions>
        </Dialog>
       
        </Main>
        </Grid>
      
    </div>

  )
}

export default Home;